package com.ebupt.webjoin.insight.json;

import org.json.JSONObject;

public class InsightJsonObject extends JSONObject {
	public InsightJsonObject()
	{
		super();
	}
 }
