package com.ebupt.webjoin.insight.intercept.util.time;

public abstract interface HasTimeStamp
{
  public abstract Time getTimeStamp();
}