package com.ebupt.webjoin.insight.intercept.util.time;

public abstract interface StopWatchFactory
{
  public abstract StopWatch createWatch();
}