package com.ebupt.webjoin.insight.intercept;

public interface InterceptListener {

}
