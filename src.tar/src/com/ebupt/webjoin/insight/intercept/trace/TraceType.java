package com.ebupt.webjoin.insight.intercept.trace;

public enum TraceType {
	HTTP,LIFECYLE,SIMPLE;
}
