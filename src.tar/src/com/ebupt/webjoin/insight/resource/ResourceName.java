package com.ebupt.webjoin.insight.resource;

public interface ResourceName {
	  public abstract String getName();
}
