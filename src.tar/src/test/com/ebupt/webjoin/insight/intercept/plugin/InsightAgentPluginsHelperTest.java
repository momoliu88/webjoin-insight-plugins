package test.com.ebupt.webjoin.insight.intercept.plugin;

 
import junit.framework.TestCase;

public class InsightAgentPluginsHelperTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testGetCanonicalURLValueFile() {
 	}

}
